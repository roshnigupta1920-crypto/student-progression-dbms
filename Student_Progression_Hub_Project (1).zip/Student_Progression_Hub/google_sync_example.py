"""
Optional Google Sheets sync example.
Prerequisites:
- service_account.json in the project folder
- GOOGLE_SPREADSHEET_ID environment variable set
- spreadsheet shared with the service-account email as Editor
Install: pip install gspread google-auth pandas
"""
import os, sqlite3
import pandas as pd
import gspread
from google.oauth2.service_account import Credentials

SCOPES = [
    "https://www.googleapis.com/auth/spreadsheets",
    "https://www.googleapis.com/auth/drive",
]
creds = Credentials.from_service_account_file("service_account.json", scopes=SCOPES)
client = gspread.authorize(creds)
spreadsheet = client.open_by_key(os.environ["GOOGLE_SPREADSHEET_ID"])

con = sqlite3.connect("student_progression.db")
for table in ["students", "semesters", "subjects", "portfolio"]:
    df = pd.read_sql_query(f"SELECT * FROM {table}", con)
    try:
        ws = spreadsheet.worksheet(table)
        ws.clear()
    except gspread.WorksheetNotFound:
        ws = spreadsheet.add_worksheet(title=table, rows=max(len(df)+1, 100), cols=max(len(df.columns), 10))
    values = [df.columns.tolist()] + df.fillna("").astype(str).values.tolist()
    ws.update(values, value_input_option="USER_ENTERED")
con.close()
print("Database tables synced to Google Sheets.")
