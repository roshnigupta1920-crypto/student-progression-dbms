# Student Progression Hub — DBMS Mini Project

## Run on Windows
1. Extract this ZIP into a folder, for example `Desktop\student_progression_project`.
2. Open that folder in File Explorer.
3. Click the address bar, type `cmd`, and press Enter.
4. Run:
   ```
   python -m pip install -r requirements.txt
   ```
5. Then run:
   ```
   python -m streamlit run app.py
   ```
6. Browser opens the local app. If not, open `http://localhost:8501`.

## Included features
- Normalized relational tables: students, semesters, subjects, portfolio.
- Student create/delete, search by name.
- Semester SGPA/CGPA, subject theory/lab marks, gap-year indicator.
- Seminar internal/external and technical/co-curricular/extra-curricular filters.
- Progression line graph.
- CSV export for each table.
- Optional Google Sheets sync example.

## Important Google Sheets note
CSV export is NOT live Google Sheets synchronization. To sync live, configure Google Sheets API credentials as described in the app and run:
`python google_sync_example.py`
This example syncs all database tables one-way when manually run. To meet strict real-time sync requirements, the sync function must be called after every successful database commit and Google credentials must be configured.

## Viva summary
The project uses separate tables to reduce repeated data. Primary keys identify rows, foreign keys link related tables, and CHECK/UNIQUE constraints reject invalid marks, SGPA/CGPA, semester numbers and duplicate roll/semester records. ON DELETE CASCADE removes related child rows when a student or semester is deleted.
