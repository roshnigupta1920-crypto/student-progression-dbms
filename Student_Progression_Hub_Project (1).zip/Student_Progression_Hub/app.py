import os, sqlite3
import pandas as pd
import streamlit as st
import plotly.express as px

DB = "student_progression.db"
st.set_page_config(page_title="Student Progression Hub", page_icon=None, layout="wide")

def connect():
    con = sqlite3.connect(DB, check_same_thread=False)
    con.execute("PRAGMA foreign_keys = ON")
    return con

def init_db():
    con = connect()
    con.executescript("""
    CREATE TABLE IF NOT EXISTS students(
        student_id INTEGER PRIMARY KEY AUTOINCREMENT,
        roll_no TEXT NOT NULL UNIQUE,
        name TEXT NOT NULL,
        email TEXT,
        secondary_marks REAL CHECK(secondary_marks IS NULL OR secondary_marks BETWEEN 0 AND 100),
        higher_secondary_marks REAL CHECK(higher_secondary_marks IS NULL OR higher_secondary_marks BETWEEN 0 AND 100),
        admission_year INTEGER,
        current_status TEXT NOT NULL DEFAULT 'Studying'
    );
    CREATE TABLE IF NOT EXISTS semesters(
        semester_id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id INTEGER NOT NULL,
        semester_no INTEGER NOT NULL CHECK(semester_no BETWEEN 1 AND 8),
        academic_year TEXT,
        sgpa REAL NOT NULL CHECK(sgpa BETWEEN 0 AND 10),
        cgpa REAL CHECK(cgpa IS NULL OR cgpa BETWEEN 0 AND 10),
        gap_year INTEGER NOT NULL DEFAULT 0 CHECK(gap_year IN (0,1)),
        UNIQUE(student_id, semester_no),
        FOREIGN KEY(student_id) REFERENCES students(student_id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS subjects(
        subject_id INTEGER PRIMARY KEY AUTOINCREMENT,
        semester_id INTEGER NOT NULL,
        subject_name TEXT NOT NULL,
        subject_type TEXT NOT NULL CHECK(subject_type IN ('Theory','Lab')),
        marks REAL NOT NULL CHECK(marks BETWEEN 0 AND 100),
        FOREIGN KEY(semester_id) REFERENCES semesters(semester_id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS portfolio(
        portfolio_id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id INTEGER NOT NULL,
        category TEXT NOT NULL CHECK(category IN ('Seminar','Technical/Co-curricular','Extra-curricular')),
        seminar_type TEXT CHECK(seminar_type IN ('Internal','External') OR seminar_type IS NULL),
        title TEXT NOT NULL,
        event_year INTEGER,
        details TEXT,
        FOREIGN KEY(student_id) REFERENCES students(student_id) ON DELETE CASCADE
    );
    """)
    con.commit()
    con.close()

init_db()
st.title("Student Progression Hub")
st.caption("DBMS Mini-Project | Student academic records, portfolios and progression analytics")

with st.sidebar:
    st.header("Navigation")
    page = st.radio("Choose module", ["Dashboard", "Student Records", "Semester & Marks", "Portfolio", "Spreadsheet Sync", "Technical Notes"])

con = connect()

if page == "Dashboard":
    students = pd.read_sql_query("SELECT * FROM students ORDER BY name", con)
    sem = pd.read_sql_query("""SELECT s.name, se.semester_no, se.sgpa, se.cgpa, se.gap_year
        FROM semesters se JOIN students s ON s.student_id=se.student_id
        ORDER BY s.name, se.semester_no""", con)
    a,b,c = st.columns(3)
    a.metric("Students", len(students))
    b.metric("Semester records", len(sem))
    c.metric("Drop/gap markers", int(sem["gap_year"].sum()) if not sem.empty else 0)
    st.subheader("Search students")
    q = st.text_input("Search by student name")
    if q:
        students = students[students["name"].str.contains(q, case=False, na=False)]
    st.dataframe(students, use_container_width=True, hide_index=True)
    st.subheader("Semester progression")
    if not sem.empty:
        names = sorted(sem["name"].unique().tolist())
        chosen = st.selectbox("Select student", names)
        chartdata = sem[sem["name"] == chosen].copy()
        chartdata["Gap marker"] = chartdata["gap_year"].map({1:"Gap year",0:"Regular"})
        fig = px.line(chartdata, x="semester_no", y=["sgpa","cgpa"], markers=True,
                      title=f"SGPA / CGPA progression: {chosen}",
                      labels={"semester_no":"Semester","value":"Grade point","variable":"Metric"})
        gaps = chartdata[chartdata["gap_year"] == 1]
        if not gaps.empty:
            fig.add_scatter(x=gaps["semester_no"], y=gaps["sgpa"], mode="markers",
                            marker=dict(size=14, symbol="x"), name="Gap year")
        st.plotly_chart(fig, use_container_width=True)
        st.dataframe(chartdata, use_container_width=True, hide_index=True)
    else:
        st.info("Add student and semester records to display the progression graph.")

elif page == "Student Records":
    st.subheader("Add student")
    with st.form("student_add", clear_on_submit=True):
        c1,c2 = st.columns(2)
        roll = c1.text_input("Roll number*")
        name = c2.text_input("Student name*")
        email = c1.text_input("Email")
        admission = c2.number_input("Admission year", min_value=2000, max_value=2100, value=2025)
        sec = c1.number_input("Secondary marks (%)", min_value=0.0, max_value=100.0, value=0.0)
        hsc = c2.number_input("Higher Secondary marks (%)", min_value=0.0, max_value=100.0, value=0.0)
        status = st.selectbox("Current status", ["Studying","Graduated","Drop/Gap","Discontinued"])
        submitted = st.form_submit_button("Save student")
        if submitted:
            if not roll.strip() or not name.strip():
                st.error("Roll number and student name are required.")
            else:
                try:
                    con.execute("""INSERT INTO students(roll_no,name,email,secondary_marks,higher_secondary_marks,admission_year,current_status)
                    VALUES(?,?,?,?,?,?,?)""",(roll.strip(),name.strip(),email.strip(),sec,hsc,admission,status))
                    con.commit(); st.success("Student saved.")
                except sqlite3.IntegrityError as e:
                    st.error(f"Could not save: {e}. Roll number must be unique.")
    st.subheader("Existing students / delete")
    df = pd.read_sql_query("SELECT * FROM students ORDER BY student_id DESC", con)
    st.dataframe(df, use_container_width=True, hide_index=True)
    if not df.empty:
        sid = st.selectbox("Student ID to delete", df["student_id"].tolist())
        if st.button("Delete selected student"):
            con.execute("DELETE FROM students WHERE student_id=?", (int(sid),)); con.commit()
            st.warning("Student deleted. Related semester and portfolio rows cascade-delete.")

elif page == "Semester & Marks":
    st.subheader("Add semester record")
    students = pd.read_sql_query("SELECT student_id, roll_no, name FROM students ORDER BY name", con)
    if students.empty:
        st.warning("Add a student first.")
    else:
        with st.form("semester_add", clear_on_submit=True):
            opts = {f'{r.roll_no} — {r["name"]} (ID {r.student_id})': int(r.student_id) for _,r in students.iterrows()}
            selected = st.selectbox("Student", list(opts.keys()))
            c1,c2,c3 = st.columns(3)
            sno = c1.selectbox("Semester", list(range(1,9)))
            year = c2.text_input("Academic year", placeholder="2025-26")
            sgpa = c3.number_input("SGPA (0–10)", min_value=0.0, max_value=10.0, value=0.0, step=0.1)
            cgpa = c1.number_input("CGPA (0–10)", min_value=0.0, max_value=10.0, value=0.0, step=0.1)
            gap = c2.checkbox("Mark this as a drop/gap year")
            save_sem = st.form_submit_button("Save semester")
            if save_sem:
                try:
                    con.execute("INSERT INTO semesters(student_id,semester_no,academic_year,sgpa,cgpa,gap_year) VALUES(?,?,?,?,?,?)",
                                (opts[selected],sno,year,sgpa,cgpa,int(gap)))
                    con.commit(); st.success("Semester saved.")
                except sqlite3.IntegrityError as e:
                    st.error(f"Could not save: {e}. A semester number can be entered only once per student.")
    st.subheader("Add theory or lab subject marks")
    sems = pd.read_sql_query("""SELECT se.semester_id, s.name, s.roll_no, se.semester_no
       FROM semesters se JOIN students s ON s.student_id=se.student_id ORDER BY s.name,se.semester_no""", con)
    if not sems.empty:
        labels = {f'{r.roll_no} — {r["name"]}, Sem {r.semester_no} (record {r.semester_id})': int(r.semester_id) for _,r in sems.iterrows()}
        with st.form("subject_add", clear_on_submit=True):
            label = st.selectbox("Semester record", list(labels.keys()))
            subj = st.text_input("Subject / lab name")
            typ = st.selectbox("Type", ["Theory","Lab"])
            marks = st.number_input("Marks (0–100)", min_value=0.0, max_value=100.0, value=0.0)
            save_sub = st.form_submit_button("Save subject marks")
            if save_sub:
                if not subj.strip(): st.error("Enter a subject name.")
                else:
                    con.execute("INSERT INTO subjects(semester_id,subject_name,subject_type,marks) VALUES(?,?,?,?)",
                                (labels[label],subj.strip(),typ,marks))
                    con.commit(); st.success("Subject marks saved.")
    allmarks = pd.read_sql_query("""SELECT s.name,s.roll_no,se.semester_no,se.academic_year,se.sgpa,se.cgpa,se.gap_year,
        su.subject_name,su.subject_type,su.marks FROM semesters se JOIN students s ON s.student_id=se.student_id
        LEFT JOIN subjects su ON su.semester_id=se.semester_id ORDER BY s.name,se.semester_no,su.subject_type""", con)
    st.subheader("All semester, theory and lab marks")
    st.dataframe(allmarks, use_container_width=True, hide_index=True)

elif page == "Portfolio":
    st.subheader("Add seminar or activity")
    students = pd.read_sql_query("SELECT student_id,roll_no,name FROM students ORDER BY name", con)
    if students.empty:
        st.info("Add a student first.")
    else:
        with st.form("portfolio_add", clear_on_submit=True):
            opts = {f'{r.roll_no} — {r["name"]}':int(r.student_id) for _,r in students.iterrows()}
            student = st.selectbox("Student", list(opts.keys()))
            category = st.selectbox("Category", ["Seminar","Technical/Co-curricular","Extra-curricular"])
            seminar_type = st.selectbox("Seminar type (for seminars)", ["Not applicable","Internal","External"])
            title = st.text_input("Title / activity name")
            year = st.number_input("Year", min_value=2000, max_value=2100, value=2026)
            details = st.text_area("Details")
            save = st.form_submit_button("Save portfolio item")
            if save:
                if not title.strip(): st.error("Title is required.")
                else:
                    stype = seminar_type if category == "Seminar" and seminar_type != "Not applicable" else None
                    con.execute("INSERT INTO portfolio(student_id,category,seminar_type,title,event_year,details) VALUES(?,?,?,?,?,?)",
                                (opts[student],category,stype,title.strip(),year,details.strip()))
                    con.commit(); st.success("Portfolio item saved.")
    data = pd.read_sql_query("""SELECT p.portfolio_id,s.name,s.roll_no,p.category,p.seminar_type,p.title,p.event_year,p.details
        FROM portfolio p JOIN students s ON s.student_id=p.student_id ORDER BY p.event_year DESC""", con)
    st.subheader("Portfolio filters")
    if not data.empty:
        fcat = st.selectbox("Filter category", ["All"] + sorted(data["category"].dropna().unique().tolist()))
        fsem = st.selectbox("Filter seminar type", ["All","Internal","External"])
        if fcat != "All": data = data[data["category"] == fcat]
        if fsem != "All": data = data[data["seminar_type"] == fsem]
    st.dataframe(data, use_container_width=True, hide_index=True)

elif page == "Spreadsheet Sync":
    st.subheader("Google Sheets one-way sync")
    st.write("This module exports database tables to CSV immediately. For direct Google Sheets syncing, add a Google service-account JSON key and set the spreadsheet ID.")
    if st.button("Export current database tables to CSV"):
        for table in ["students","semesters","subjects","portfolio"]:
            pd.read_sql_query(f"SELECT * FROM {table}", con).to_csv(f"{table}_export.csv", index=False)
        st.success("CSV exports created in the project folder.")
    st.markdown("""
**Optional live Google Sheets setup**
1. Create a Google Cloud project and enable Google Sheets API and Google Drive API.
2. Create a service account and download its JSON key as `service_account.json` into this folder.
3. Create a Google spreadsheet and share it with the service-account email as Editor.
4. Set environment variable `GOOGLE_SPREADSHEET_ID` to the spreadsheet ID.
5. Install `gspread` and `google-auth`, then use the sync function in `google_sync_example.py`.
""")
    st.caption("CSV export is not live sync. Do not claim live Google Sheets sync until the Google credentials are configured and tested.")

elif page == "Technical Notes":
    st.subheader("Schema and constraints")
    st.markdown("""
- **3NF-oriented relational design:** student profile, semester, subject marks, and portfolio items are stored separately.
- **Primary keys:** each table has its own integer primary key.
- **Foreign keys:** semester → student, subject → semester, portfolio → student.
- **Referential actions:** `ON DELETE CASCADE` removes child records when a parent is deleted.
- **CHECK constraints:** secondary/HSC marks 0–100; subject marks 0–100; SGPA/CGPA 0–10; semester 1–8; allowed categories/status values.
- **Duplicate control:** roll number is unique; one semester number per student is enforced.
- **Validation handling:** invalid values and duplicates display an error instead of silently saving.
- **CRUD:** create and delete are available in the GUI; records are stored in `student_progression.db`.
- **Spreadsheet:** CSV export is included; live Google Sheets sync requires valid Google API credentials.
""")
    st.subheader("How to update database directly")
    st.code("""import sqlite3
con = sqlite3.connect("student_progression.db")
con.execute("PRAGMA foreign_keys = ON")
con.execute("UPDATE students SET current_status=? WHERE roll_no=?", ("Graduated", "ROLL001"))
con.commit()
con.close()""", language="python")

con.close()
